#Output_All_results_single-copy
#In the terminal run:
##Step 1
./PANAS.sh -p CDS_AA/ -n CDS_NUC/ -o Pair -z 8 -a mafft -g 1 -t other -s single-copy

#Nucleotide (or amino acid) sequences in "CDS_AA" or "CDS_NUC" may be in FASTA files separated by species or by gene, or they may be in a single FASTA file. Each sequence must have a different code.

#This dataset replicates part of the results obtained by Drouin et al. (2008), using the M0 model.
#Drouin, G., Daoud, H., & Xia, J. (2008). Relative rates of synonymous substitutions in the mitochondrial, chloroplast and nuclear genomes of seed plants. Molecular phylogenetics and evolution, 49(3), 827-831.
