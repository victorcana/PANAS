#####These are the steps to generate the results of the article and generate the graphs.

#In the terminal run:
##Step 1
./PANAS.sh -p CDS_AA/ -n CDS_NUC/ -o Pair/ -z 8 -a mafft -g 1 -t OMA -s single-copy

#Nucleotide (or amino acid) sequences in "CDS_AA" or "CDS_NUC" may be in FASTA files separated by species or by gene, or they may be in a single FASTA file. Each sequence must have a different code.

#This dataset replicates part of the results obtained by Liang et al. (2022), using the M0 model.
#Liang Y, Choi H-G, Zhang S, Hu Z-M, Duan D (2022) The organellar genomes of Silvetia siliquosa (Fucales, Phaeophyceae) and comparative analyses of the brown algae. PLoS ONE 17(6): e0269631. https://doi.org/10.1371/journal.pone.0269631
