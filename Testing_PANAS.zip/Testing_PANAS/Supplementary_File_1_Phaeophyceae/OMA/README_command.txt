#Install OMA to obtain the pairwise OGs.
#The codes of the sequences that are in the DB file were modified to run with OMA. There is one fasta file for each species. The codes used in these fastas files are the same codes as the fastas files (nucleotides and amino acids) used to run PANAS.
#OMA generates an Output directory, where all the results are. The "PairwiseOrthologs" file inside Output contains the information on the pairwise OGs.


#In the terminal run:
##Step 1
~/oma -n 4


#For more information see: Altenhoff AM, Levy J, Zarowiecki M, Tomiczek B, Vesztrocy AW, Dalquen DA, Müller S, Telford MJ, Glover NM, Dylus D, Dessimoz C. Corrigendum: OMA standalone: orthology inference among public and custom genomes and transcriptomes. Genome Res. 2020 Jun;30(6):9382. doi: 10.1101/gr.266809.120. Erratum for: Genome Research 29: 1152–1163 (2019). PMCID: PMC7370885.
