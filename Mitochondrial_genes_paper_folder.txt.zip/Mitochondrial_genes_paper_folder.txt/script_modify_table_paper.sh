paste Todos_resultados_single-copy <(cut -f1 Todos_resultados_single-copy | sed 's/ID_1/Gene/ ; s/_.*//')  > Todos_resultados_single-copy_modificado

paste Todos_resultados_single-copy_modificado <(cut -f5 Todos_resultados_single-copy | sed 's/.txt// ; s/PairwiseOrthologs/PairwiseOrthologs_2/ ; s/Echinococcus_multilocularis_AB018440/E_mul/ ; s/Schmidtea_mediterranea_JX398125/S_med/ ; s/Neobenedenia_melleni_JQ038228/N_mel/ ; s/Fasciola_hepatica_AF216697/F_hep/ ; s/Taenia_asiatica_AP017670/T_asi/ ; s/Schistosoma_mansoni_AF216698/S_man/ ; s/Hymenolepis_microstoma_LC102493/H_mic/ ; s/Eudiplozoon_nipponicum_MW704020/E_nip/ ; s/Scutogyrus_longicornis_NC_056186/S_lon/ ; s/Rhabdosynochus_viridisi_MW565922/R_vir/ ; s/Gyrodactylus_salaris_NC_008815/G_sal/')  > Todos_resultados_single-copy_3 && mv Todos_resultados_single-copy_3 Todos_resultados_single-copy_modificado

sed -i 's/PairwiseOrthologs_2/PairwiseOrthologs_2\tClass/ ; s/E_mul-H_mic/E_mul-H_mic\tCestoda/ ; s/E_mul-T_asi/E_mul-T_asi\tCestoda/ ; s/H_mic-T_asi/H_mic-T_asi\tCestoda/ ; s/G_sal-N_mel/G_sal-N_mel\tMonopisthocotylea/ ; s/G_sal-R_vir/G_sal-R_vir\tMonopisthocotylea/ ; s/G_sal-S_lon/G_sal-S_lon\tMonopisthocotylea/ ; s/N_mel-R_vir/N_mel-R_vir\tMonopisthocotylea/ ; s/N_mel-S_lon/N_mel-S_lon\tMonopisthocotylea/ ; s/R_vir-S_lon/R_vir-S_lon\tMonopisthocotylea/ ; s/F_hep-S_man/F_hep-S_man\tTrematoda/' Todos_resultados_single-copy_modificado










