library(ggplot2)

Prueba_mito9 <- read.csv("Todos_resultados_single-copy_modificado", sep = "\t")

#Mitocondrial

#install.packages("patchwork")      # Install & load patchwork package
library("patchwork")


################Paper######
###Cestoda_Monopisthocotylea_Trematoda

#Mitocondrial
#dN
dN_mtc1 <- ggplot(Prueba_mito9[Prueba_mito9$dN <= 50 & Prueba_mito9$Class != "" , ], aes(dN,  color =  Class ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

dN_mtc2 <-ggplot(Prueba_mito9[Prueba_mito9$dN <= 50 & Prueba_mito9$Class != "" ,], aes(y=Class, dN,  color =  Class ))  +  
  theme_minimal()+theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
 scale_y_discrete(limits=c("Trematoda", "Monopisthocotylea", "Cestoda"))+
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5,hjust=0.5) )

dN_mtc12 <- (dN_mtc1) / dN_mtc2
dN_mtc12

#dS
dS_mtc1 <- ggplot(Prueba_mito9[Prueba_mito9$dS <= 200 & Prueba_mito9$Class != "" , ], aes(dS,  color =  Class ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

dS_mtc2 <-ggplot(Prueba_mito9[Prueba_mito9$dS <= 200 & Prueba_mito9$Class != "" ,], aes(y=Class, dS,  color =  Class ))  +  
  theme_minimal()+theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("Trematoda", "Monopisthocotylea", "Cestoda"))+
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5,hjust=0.5) )

dS_mtc12 <- (dS_mtc1) / dS_mtc2
dS_mtc12





dN_dS_mtc12 <- (dN_mtc1 + dS_mtc1) / (dN_mtc2 + dS_mtc2)
dN_dS_mtc12


###TODO

#Mitocondrial
#dN
dN_todo1 <- ggplot(Prueba_mito9[Prueba_mito9$dN <= 50 , ], aes(dN,  color =  Gene ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired") +
  xlim(0, 3)

dN_todo2 <-ggplot(Prueba_mito9[Prueba_mito9$dN <= 50,], aes(y=Gene, dN,  color =  Gene ))  +  
  theme_minimal()+ theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("nad6", "nad5", "nad4L", "nad4", "nad3", "nad2", "nad1", "cytb", "cox3","cox2", "cox1", "atp6"))+
  xlim(0, 3)

dN_todo12 <- (dN_todo1) / dN_todo2
dN_todo12

#dS
dS_todo1 <- ggplot(Prueba_mito9[Prueba_mito9$dS <= 200  , ], aes(dS,  color =  Gene ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

dS_todo2 <-ggplot(Prueba_mito9[Prueba_mito9$dS <= 200  ,], aes(y=Gene, dS,  color =  Gene ))  +  
  theme_minimal()+ theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("nad6", "nad5", "nad4L", "nad4", "nad3", "nad2", "nad1", "cytb", "cox3","cox2", "cox1", "atp6"))

dS_todo12 <-  dS_todo1 /   dS_todo2
dS_todo12

dSdN_todo12 <- (dN_todo1 + dS_todo1) / (dN_todo2 + dS_todo2)
dSdN_todo12


###Análsiuis pareado Mono Trematoda Cestoda
##dN

paired <- Prueba_mito9[Prueba_mito9$Class != ""  ,]
##Para ordenar los pareados poniendo primero los cestodos, luego los monogéneos y finalmente los trematodos
paired$PairwiseOrthologs_2 <- factor(paired$PairwiseOrthologs_2,levels = c("E_mul-H_mic", "E_mul-T_asi", "H_mic-T_asi", "G_sal-N_mel",
                                               "G_sal-R_vir", "G_sal-S_lon", "N_mel-R_vir", "N_mel-S_lon", "R_vir-S_lon","F_hep-S_man") )

gr1 <- ggplot(data=paired[paired$dN <= 50 & paired$Class != ""  ,], mapping=aes(x=Gene, y=dN, fill = Gene)) + 
  stat_summary(fun.data=mean_sdl, geom="bar") + #para agregar valores a la barra geom_text( aes( label = paste0( dN), y = dN ), vjust = 1.4, size = 1, color = "black" )+
  facet_wrap(~ PairwiseOrthologs_2) + theme(legend.position="right")+
  scale_fill_brewer(palette="Paired") +# theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,hjust=0.5) )+
  ylim(0,3.1)
#dS 
gr2 <- ggplot(data=paired[paired$dS <= 200 & paired$Class != ""  ,], mapping=aes(x=Gene, y=dS, fill = Gene)) + 
  stat_summary(fun.data=mean_sdl, geom="bar") + #para agregar valores a la barra geom_text( aes( label = paste0( dN), y = dN ), vjust = 1.4, size = 1, color = "black" )+
  facet_wrap(~ PairwiseOrthologs_2) + theme(legend.position="botton")+
  scale_fill_brewer(palette="Paired") +# theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,hjust=0.5) )
gr12 <-  gr1  /  gr2
gr12
  
  


