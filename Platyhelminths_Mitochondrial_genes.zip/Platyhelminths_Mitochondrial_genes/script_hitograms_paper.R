library(ggplot2)

Prueba_mito9 <- read.csv("All_results_single-copy_modified", sep = "\t")

#Mitocondrial

#install.packages("patchwork")      # Install & load patchwork package
library("patchwork")


################Paper######
###Cestoda_Monopisthocotylea_Trematoda

#Mitocondrial
#Ka
Ka_mtc1 <- ggplot(Prueba_mito9[Prueba_mito9$Ka <= 50 & Prueba_mito9$Class != "" , ], aes(Ka,  color =  Class ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

Ka_mtc2 <-ggplot(Prueba_mito9[Prueba_mito9$Ka <= 50 & Prueba_mito9$Class != "" ,], aes(y=Class, Ka,  color =  Class ))  +  
  theme_minimal()+theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
 scale_y_discrete(limits=c("Trematoda", "Monopisthocotylea", "Cestoda"))+
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5,hjust=0.5) )

Ka_mtc12 <- (Ka_mtc1) / Ka_mtc2
Ka_mtc12

#Ks
Ks_mtc1 <- ggplot(Prueba_mito9[Prueba_mito9$Ks <= 200 & Prueba_mito9$Class != "" , ], aes(Ks,  color =  Class ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

Ks_mtc2 <-ggplot(Prueba_mito9[Prueba_mito9$Ks <= 200 & Prueba_mito9$Class != "" ,], aes(y=Class, Ks,  color =  Class ))  +  
  theme_minimal()+theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("Trematoda", "Monopisthocotylea", "Cestoda"))+
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5,hjust=0.5) )

Ks_mtc12 <- (Ks_mtc1) / Ks_mtc2
Ks_mtc12





Ka_Ks_mtc12 <- (Ka_mtc1 + Ks_mtc1) / (Ka_mtc2 + Ks_mtc2)
Ka_Ks_mtc12


###All

#Mitocondrial
#Ka
Ka_todo1 <- ggplot(Prueba_mito9[Prueba_mito9$Ka <= 50 , ], aes(Ka,  color =  Gene ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired") +
  xlim(0, 3)

Ka_todo2 <-ggplot(Prueba_mito9[Prueba_mito9$Ka <= 50,], aes(y=Gene, Ka,  color =  Gene ))  +  
  theme_minimal()+ theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("nad6", "nad5", "nad4L", "nad4", "nad3", "nad2", "nad1", "cytb", "cox3","cox2", "cox1", "atp6"))+
  xlim(0, 3)

Ka_todo12 <- (Ka_todo1) / Ka_todo2
Ka_todo12

#Ks
Ks_todo1 <- ggplot(Prueba_mito9[Prueba_mito9$Ks <= 200  , ], aes(Ks,  color =  Gene ))  +  
  geom_density(alpha = 0.0) + ggtitle("Single-copy OGs") + 
  theme_minimal()+theme(legend.position="top") + #facet_wrap(~ Gen) + #theme_classic() + 
  geom_density(alpha = 0.0) + scale_color_brewer(palette="Paired")

Ks_todo2 <-ggplot(Prueba_mito9[Prueba_mito9$Ks <= 200  ,], aes(y=Gene, Ks,  color =  Gene ))  +  
  theme_minimal()+ theme(legend.position="botton") +
  geom_boxplot( outlier.colour="black", notch=FALSE,  alpha = 0.1, notchwidth = 0.09 ) +
  scale_color_brewer(palette="Paired") +
  scale_y_discrete(limits=c("nad6", "nad5", "nad4L", "nad4", "nad3", "nad2", "nad1", "cytb", "cox3","cox2", "cox1", "atp6"))

Ks_todo12 <-  Ks_todo1 /   Ks_todo2
Ks_todo12

KsKa_todo12 <- (Ka_todo1 + Ks_todo1) / (Ka_todo2 + Ks_todo2)
KsKa_todo12


###Paired analysis Monopisthocotylea Trematoda Cestoda
##Ka

paired <- Prueba_mito9[Prueba_mito9$Class != ""  ,]
##To order the couplets putting first the cestodes, then the monogeneans and finally the trematodes
paired$PairwiseOrthologs_2 <- factor(paired$PairwiseOrthologs_2,levels = c("E_mul-H_mic", "E_mul-T_asi", "H_mic-T_asi", "G_sal-N_mel",
                                               "G_sal-R_vir", "G_sal-S_lon", "N_mel-R_vir", "N_mel-S_lon", "R_vir-S_lon","F_hep-S_man") )

gr1 <- ggplot(data=paired[paired$Ka <= 50 & paired$Class != ""  ,], mapping=aes(x=Gene, y=Ka, fill = Gene)) + 
  stat_summary(fun.data=mean_sdl, geom="bar") + #to add values to the bar geom_text( aes( label = paste0( Ka), y = Ka ), vjust = 1.4, size = 1, color = "black" )+
  facet_wrap(~ PairwiseOrthologs_2) + theme(legend.position="right")+
  scale_fill_brewer(palette="Paired") +# theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,hjust=0.5) )+
  ylim(0,3.1)
#Ks 
gr2 <- ggplot(data=paired[paired$Ks <= 200 & paired$Class != ""  ,], mapping=aes(x=Gene, y=Ks, fill = Gene)) + 
  stat_summary(fun.data=mean_sdl, geom="bar") + #to add values to the bar geom_text( aes( label = paste0( Ka), y = Ka ), vjust = 1.4, size = 1, color = "black" )+
  facet_wrap(~ PairwiseOrthologs_2) + theme(legend.position="botton")+
  scale_fill_brewer(palette="Paired") +# theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5,hjust=0.5) )
gr12 <-  gr1  /  gr2
gr12
  
  


