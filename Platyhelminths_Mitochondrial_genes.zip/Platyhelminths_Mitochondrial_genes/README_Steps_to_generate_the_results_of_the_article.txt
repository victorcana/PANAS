#####These are the steps to generate the results of the article and generate the graphs.

#In the terminal run:
##Step 1
./PANAS.sh -p CDS_AA/ -n CDS_NUC/ -o PairwiseOrthologs/ -z 8 -a mafft -g 9 -t OMA -s single-copy
##Step 2. This script is specific to the data generated in this study. Using it with other data can lead to error.
./script_modify_table_paper.sh

#In R open:
##Step 3
script_hitograms_paper

