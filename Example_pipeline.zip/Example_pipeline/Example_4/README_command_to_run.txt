#In the terminal run:
##Step 1
./PANAS.sh -p protein_directory/ -n nucleotide_directory/ -o Orthologs/ -z 8 -a mafft -g 9 -t OMA -s single-copy
